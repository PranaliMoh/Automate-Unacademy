package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.annotation.JsonAppend.Prop;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class login_Success_1 {
	WebDriver driver;
	
	Properties prop = new Properties();
	
	@Given("User is on his Home Page")
	public void user_is_on_his_Home_page() throws IOException {
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("https://unacademy.com/");
		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	
	@When("Registered mobaile enter")
	public void Registered_mobaile_enter() throws InterruptedException, IOException {
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		prop.load(ip);
		driver.findElement(By.xpath(prop.getProperty("loginbutton1"))).click();
		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		//driver.findElement(By.xpath("/html/body/div[3]/div[3]/div[2]/div[2]/div/input")).sendKeys("9359993917");
		
		  WebElement mob = driver.findElement(By.xpath(prop.getProperty("mobilenumber")));
		  mob.sendKeys("9359993917");
		 
		String fn=mob.getAttribute("value");
		  if (fn.length()<3 || fn.length()>15 ) { 
			  System.out.println(driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).isDisplayed());
			  
		  }
		  driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		  driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).click();//green login2
		
		Thread.sleep(3000);
	}
	
	@When("enters OTP")
	public void enters_otp() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/form/div/input")).click();
		Thread.sleep(15000);
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/button")).click();
		Thread.sleep(3000);
	}
	
	@Then("successfully Logged in using mobile")
	public void successfully_Logged_in_using_mobile() throws InterruptedException {
		
		Thread.sleep(3000);
		driver.close();
		//Thread.sleep(3000);
		//driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[2]/div[3]/picture/img")).click();
		 Thread.sleep(3000);
		
		 //driver.findElement(By.xpath(prop.getProperty("logout"))).click();
		 
		 
	}
	
		
	   @Then("user succefully logout")
	   public void user_succefully_logout() throws InterruptedException, IOException
	{ 
		 
		 FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		  prop.load(ip); 
		  driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[2]/div[3]/picture/img")).click();
		  //driver.findElement(By.xpath(prop.getProperty("profile"))).click();
		  driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		  
		  driver.findElement(By.xpath(prop.getProperty("logout"))).click();
		  
		  Thread.sleep(3000); driver.close();
		 
		      
	   }
	}
	
	



