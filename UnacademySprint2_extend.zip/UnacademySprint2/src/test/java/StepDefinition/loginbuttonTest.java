package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import org.testng.annotations.Test;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginbuttonTest{
	WebDriver driver;
	
	@BeforeTest
	@Given("user open google")
	public void user_open_google() {
		 System.out.println("browser is open using hooks");
			System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe"); 
			driver = new ChromeDriver();
				//driver.get("https://google.com");
	}
	@BeforeMethod
	@When("Type url")
	public void type_url() {
		driver.get("https://google.com");
		driver.findElement(By.name("q")).sendKeys("unacademy");
//		 //driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
//			 
		 driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			 driver.findElement(By.xpath("//h3[starts-with(text(),\"Unacademy - India's largest \")]")).click();
//			 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	    
	}
	@Test(priority = 0)
	@Then("I validate the outcome")
	public void i_validate_the_outcome() throws Exception {
		String reg=driver.getTitle();
	String str2="Unacademy - India's largest learning platform";
		if (reg.equals(str2)) {
			System.out.println("Login page for unacademy title Verified");
		}
		else
		{
			driver.navigate().back();
		}
	   	//driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	  	Thread.sleep(3000);
	  //	driver.close();
	   
	}
	
	
	@Test(priority = 1)
	@Then("unacademy logo is visible at top right corner")
	public void unacademy_logo_is_visible_at_top_right_corner() {
		driver= new ChromeDriver();
		driver.get("https://unacademy.com/");
//		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/button[1]")).click();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		//Thread.sleep(3000);
		//driver.close();
	   
	}

	
	

	
	@Test(priority = 2)
	@Then("user is on Login page")
	public void user_is_on_login_page() {
		driver= new ChromeDriver();
		driver.get("https://unacademy.com/");
		//System.out.println(driver.getCurrentUrl());
		
	driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
//		
	}

//
//	@AfterMethod
//	public void closedriver()
//	{
//		//driver.close();
//	}





}