package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Verification_through_email {
		WebDriver driver;
		Properties prop = new Properties();
	@Given("user able conntinue with email")
	public void user_able_conntinue_with_email() throws IOException {
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		  prop.load(ip);
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://unacademy.com");
		//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.findElement(By.xpath(prop.getProperty("loginbutton1"))).click();
		//driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
	}
	@When("user click on coninue link")
	public void user_click_on_coninue_link() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/a/h6")).click();
		
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	@When("user enter email and verify otp")
	public void user_enter_email_and_verify_otp() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/input")).sendKeys("mohitepranali220@gmail.com");
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div/button")).click();//  green verify otp
		Thread.sleep(3000);

		boolean assert1 =  driver.getPageSource().contains("Email is not valid");
				
		if(assert1 == true) { 
			  System.out.println("  Email Warning displayed");
		  } 
		
		
		Thread.sleep(7000);
		//driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).click(); // green login button
		
		//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		Thread.sleep(15000);
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div/button")).click();//  green verify otp
		
	}
	@Then("user navigate to Home page")
	public void user_navigate_to_home_page() throws InterruptedException {
		
		//driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		
		Thread.sleep(3000);
		driver.close();
		
	}



}
