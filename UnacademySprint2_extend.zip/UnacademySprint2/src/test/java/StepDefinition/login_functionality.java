package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class login_functionality {
	WebDriver driver;
	Properties prop = new Properties();
	@Given("User is in the Login Page")
	public void user_is_in_the_login_page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("https://unacademy.com/");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		Thread.sleep(3000);
		}
	
	@When("^User enters (.*)$")
	public void user_enters_mobile(String mobile) throws InterruptedException, IOException {
		
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		prop.load(ip);
		driver.findElement(By.xpath(prop.getProperty("loginbutton1"))).click();
		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		WebElement mob = driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/div/input"));
		mob.sendKeys(mobile);
		 Thread.sleep(3000);
		String fn=mob.getAttribute("value");
		  if (fn.length()<=3 ) { 
			 // System.out.println(driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).isDisplayed());
			  
			  driver.close();
		}
		
		  
		  
		
		//driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).click();
		Thread.sleep(7000); 
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div/button")).click();
		Thread.sleep(4000);
	}
	
	@Then("phone number is validated")
	public void Then_phone_number_is_validated() throws InterruptedException, FileNotFoundException
	{
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		try {
			prop.load(ip);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(3000);
		driver.findElement(By.xpath(prop.getProperty("continue"))).click();
		
		
		Thread.sleep(3000);
		driver.close();
		
	}

}
