package StepDefinition;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserScript {
	
WebDriver driver;
  @Parameters("browser")
  @BeforeTest
  public void setup(String browser) throws Exception {
	  if(browser.equalsIgnoreCase("firefox")) {
		  
		 
	 System.setProperty("webdriver.gecko.driver", "C:\\Users\\pranalmo\\Downloads\\geckodriver.exe");
		  
		  driver = new FirefoxDriver();
	  }
	  else if(browser.equalsIgnoreCase("chrome")) {
		  System.setProperty("webdriver.chrome.driver", "C:\\Windows\\System32\\config\\systemprofile\\eclipse-workspace\\UnacademySprint2\\Drivers\\chromedriver.exe");
		  driver = new ChromeDriver();
	  }
	  else if(browser.equalsIgnoreCase("Edge")){
			//set path to Edge.exe
			System.setProperty("webdriver.edge.driver","C:\\Windows\\System32\\config\\systemprofile\\eclipse-workspace\\UnacademySprint2\\Drivers\\msedgedriver.exe");
			//create Edge instance
			driver = new EdgeDriver();
		}
else{
	//If no browser passed throw exception
	throw new Exception("Browser is not correct");
}
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  
  }
  @Test
  public void TestingwithXml() throws InterruptedException {
	  driver.navigate().to("https://unacademy.com/");
	  
	  driver.findElement(By.xpath("//button[@color=\"green\"]")).click();
	  driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
  }
  
  @AfterTest
  public void CloseBrowser() {
	  driver.quit();
  }
  
}
