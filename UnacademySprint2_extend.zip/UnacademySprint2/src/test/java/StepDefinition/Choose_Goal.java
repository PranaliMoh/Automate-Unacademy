package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Choose_Goal {
	
	
	WebDriver driver;
	
	@Given("user is on website")
	public void user_is_on_website() {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe"); 
		  driver = new ChromeDriver();
			driver.get("https://unacademy.com/");
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			
	}
	@When("user enters start learning")
	public void user_enters_start_learning() {
	    driver.findElement(By.xpath("//span[text()= 'Start learning']")).click();
	    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	@And("user able to enter goal")
	public void user_able_to_enter_goal() {
	    driver.findElement(By.xpath("//*[@id=\"searchInput\"]")).click();
	    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//*[@id=\"searchTab\"]/div[2]/div[2]")).click();
	    
	}
	@Then("user get goal outcome")
	public void user_get_goal_outcome() {
	   //driver.findElement(By.xpath("//*[@id=\"searchTab\"]/div[2]/div[2]")).isDisplayed();
	   driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	   
	}
	

	@Then("user able to search Top Educators")
	public void user_able_to_search_Top_Educators() {
	    driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[2]/div/div/div/a[2]/div")).click();
	    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	@Then("user view batch")
	public void user_view_batch() { 
		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[2]/div/div/div/a[3]/div")).click();
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}

	@Then("user able to view SubScription Plans")
	public void user_able_to_view_sub_scription_plans() {
		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[2]/div/div/div/a[5]/div")).click();
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}

	@Then("user able to view Success Stories")
	public void user_able_to_view_success_stories() {
	    driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[2]/div/div/div/a[6]/div")).click();
	    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}

	@Then("user able to view about exam")
	public void user_able_to_view_about_exam() {
	   driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[2]/div/div/div/a[7]/div")).click();
	   driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}


//	@Then("^user able to search$") 
//	public void user_able_to_search() {
//		
//		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe"); 
//		driver= new ChromeDriver();
//		driver.get("https://unacademy.com/");
//		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div[1]/div[4]/div[1]/div")).click();
//		
//		driver.findElement(By.xpath("//input[@placeholder=\"Search for courses & educators\"]")).sendKeys("UPSE");
//		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//	}
}
