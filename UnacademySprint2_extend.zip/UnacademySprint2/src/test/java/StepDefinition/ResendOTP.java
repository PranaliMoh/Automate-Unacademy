package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ResendOTP {
	WebDriver driver;
	Properties prop = new Properties();
	/*
	 * @Before public void browser_set_up() throws InterruptedException, IOException
	 * { FileInputStream ip = new
	 * FileInputStream("/Users/PRANALI MOHITE/Downloads/eclipse-jee-neon-3-win32-x86_64/eclipse/UnacademySprint2/login.properties"
	 * ); prop.load(ip); System.setProperty(
	 * "webdriver.chrome.driver","C:\\Users\\PRANALI MOHITE\\Downloads\\chromedriver_win32\\chromedriver.exe"
	 * ); driver = new ChromeDriver();
	 * driver.navigate().to("https://unacademy.com/"); }
	 */
	
	
	@Given("OTP is in on Registred mobile")
	public void otp_is_in_on_registred_mobile() throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.navigate().to("https://unacademy.com/");
		
		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
		prop.load(ip);
		
		driver.findElement(By.xpath(prop.getProperty("loginbutton1"))).click();
		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		//driver.findElement(By.xpath("/html/body/div[3]/div[3]/div[2]/div[2]/div/input")).sendKeys("9359993917");
		
		  WebElement mob = driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/div/input"));
		  mob.sendKeys("9359993917");
		 
		String fn=mob.getAttribute("value");
		  if (fn.length()<3 || fn.length()>15 ) { 
			  System.out.println(driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).isDisplayed());
			  
		  }
		  driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		  driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[3]/button")).click();//green login2
		
		Thread.sleep(3000);
		
	WebElement OTP = driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/form/div/input"));
			OTP.sendKeys("133000");
		
			
		//Thread.sleep(15000);
		
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/button")).click();
		Thread.sleep(3000);
		
		boolean assert1 =  driver.getPageSource().contains("This OTP is not valid");
				
		if(assert1 == true) { 
			  System.out.println(" Warning displayed");
		  } 
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		System.out.println(driver.findElement(By.xpath(prop.getProperty("Resend_OTP"))).isDisplayed());
		//driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/div/a[1]/h6"));
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
	}

	@When("click on Resend button")
	public void click_on_resend_button() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/div/a[1]/h6")).click();	
		//Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		
	}
	
	@Then("user login successfully")
	public void user_login_successfully() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/form/div/input")).clear();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"DrawerPaper\"]/div[2]/div[2]/button")).click();
		
		Thread.sleep(6000);
		driver.close();
	   
	}
}
