package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.Before;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginbutton{

//	WebDriver driver;
//	//driver = new ChromeDriver();
//	
//	Properties prop = new Properties();
//
//	@Given("user open google")
//	public void user_open_google()
//	{	 System.out.println("browser is open using hooks");
//	System.setProperty("webdriver.chrome.driver","C:\\Users\\pranalmo\\Downloads\\chromedriver.exe"); 
//	driver = new ChromeDriver();
//		driver.get("https://google.com");
//	}
//	@When("Type url")
//	public void type_url() throws InterruptedException {
//		driver.findElement(By.name("q")).sendKeys("unacademy");
//		 //driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
//			 
//			 driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
//			 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//			 driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div[1]/div")).click();
//			 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
//	}
//	@Then("I validate the outcome")
//	public void I_validate_the_outcome() throws InterruptedException {
//	
//		String reg=driver.getTitle();
//		String str2="Unacademy - India's largest learning platform";
//		if (reg.equals(str2)) {
//			System.out.println("Login page for unacademy title Verified");
//		}
//		else
//		{
//			driver.navigate().back();
//		}
//	   	//driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
//	  	Thread.sleep(3000);
//	  	driver.close();
//	  	
//	}
//	
//	@Then("unacademy logo is visible at top right corner")
//	public void unacademy_logo_is_visible_at_top_right_corner() throws IOException, InterruptedException
//	{
//		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
//		prop.load(ip);
//		
//		driver= new ChromeDriver();
//		driver.get("https://unacademy.com/");
//		
//		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//		
//		driver.findElement(By.xpath(prop.getProperty("unacademyLogo_xpath"))).click();
//		Thread.sleep(3000);
//		driver.close();
//	}
//	@When("^user clicks on Login button$") 
//	public void user_clicks_on_Login_button()throws InterruptedException, IOException {
//		FileInputStream ip = new FileInputStream("/Windows/System32/config/systemprofile/eclipse-workspace/UnacademySprint2/login.properties");
//		prop.load(ip);
//		
//		driver= new ChromeDriver();
//		driver.get("https://unacademy.com/");
//		
//		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//		driver.findElement(By.xpath(prop.getProperty("loginbutton1"))).click();
//		//driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
//		Thread.sleep(3000);
//
//
//	}
//
//	@Then("^user is on Login page$") public void
//	user_should_accesible_to_login_page() throws InterruptedException{ // Write code here that turns the
//		
//		driver= new ChromeDriver();
//		driver.get("https://unacademy.com/");
//		System.out.println(driver.getCurrentUrl());
//		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
//		
//		driver.close();
//	
//		
//		}
//
//	
	
	

}





